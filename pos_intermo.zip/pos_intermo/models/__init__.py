from . import pos_payment_method
from . import pos_payment
